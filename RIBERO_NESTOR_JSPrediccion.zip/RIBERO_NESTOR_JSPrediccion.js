function myBirthYearFunc(){
    console.log("Nací en " + 1980);
}   //Nací en 1980
function myBirthYearFunc(EntradaAñoNacimiento){
    console.log("Nací en " + EntradaAñoNacimiento);
}   //Nací en 1980
function add(num1, num2){
    console.log("¡Sumando números!");
    console.log("num1 is: " + num1);
    console.log("num2 is: " + num2);
    var sum = num1 + num2;
    console.log(sum);
}   //¡Sumando números!
    //num1 is: 10
    //num2 is: 20
    //30